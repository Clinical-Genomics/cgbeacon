# instance/config.cfg

SQLALCHEMY_DATABASE_URI= \
"mysql://microaccounts_dev:r783qjkldDsiu@localhost:3306/elixir_beacon_testing"

SECRET_KEY= \
"nsady679d8+eiqåowm´´`msdjjwi"
