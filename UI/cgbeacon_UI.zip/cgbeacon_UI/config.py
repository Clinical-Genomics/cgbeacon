DEBUG = True # Turns on debugging features in Flask
