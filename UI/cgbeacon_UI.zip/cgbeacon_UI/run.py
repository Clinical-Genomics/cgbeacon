from cgbeacon_UI import app

app.run()
